# -*- coding:utf-8 -*-
__author__ = 'Ulric Qin'

from web import app

if __name__ == '__main__':
    app.run(port=5050, host="127.0.0.1", debug=True)
